package com.example.dualmapper.manager.connection

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.*
import java.util.concurrent.ConcurrentHashMap

class LanConnectionManager(private val context: Context) : SecureSocketManager() {

    private val PORT = 21000
    private val BROADCAST_PORT = 21001
    private val SERVICE_ID = "DualMapperLAN"
    private val BROADCAST_INTERVAL = 2000L

    private val _discoveredDevices = MutableStateFlow<List<DeviceInfo>>(emptyList())
    override val discoveredDevices: StateFlow<List<DeviceInfo>> = _discoveredDevices.asStateFlow()

    private var serverSocket: ServerSocket? = null
    private var clientSocket: Socket? = null
    private var listenSocket: DatagramSocket? = null
    private var broadcastSocket: DatagramSocket? = null
    private var broadcastJob: Job? = null
    private var isDiscovering = false
    private val discoveredMap = ConcurrentHashMap<String, DeviceInfo>()
    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    @Volatile
    private var isListening = false

    override fun getInputStream(): InputStream? = clientSocket?.getInputStream()
    override fun getOutputStream(): OutputStream? = clientSocket?.getOutputStream()

    private fun ensureListening() {
        if (isListening) return
        startServer()
        startBroadcastListener()
        isListening = true
    }

    private fun resetListening() {
        isListening = false
        serverSocket?.close()
        serverSocket = null
        listenSocket?.close()
        listenSocket = null
    }

    private fun getLocalIpAddress(): String? {
        val ip = wifiManager.connectionInfo.ipAddress
        return if (ip != 0) {
            String.format("%d.%d.%d.%d", ip and 0xFF, ip shr 8 and 0xFF, ip shr 16 and 0xFF, ip shr 24 and 0xFF)
        } else null
    }

    private fun getBroadcastAddress(): InetAddress? {
        val dhcp = wifiManager.dhcpInfo
        val broadcast = dhcp.ipAddress and dhcp.netmask or dhcp.netmask.inv()
        val quads = ByteArray(4)
        for (k in 0..3) {
            quads[k] = (broadcast shr k * 8 and 0xFF).toByte()
        }
        return InetAddress.getByAddress(quads)
    }

    private fun startServer() {
        // 关闭旧 ServerSocket，避免端口占用
        serverSocket?.close()
        serverSocket = null
        scope.launch {
            try {
                serverSocket = ServerSocket(PORT)
                while (isActive) {
                    val socket = serverSocket?.accept() ?: break
                    manageConnection(socket)
                }
            } catch (e: IOException) { }
        }
    }

    private fun startBroadcastListener() {
        // 关闭旧 DatagramSocket
        listenSocket?.close()
        listenSocket = null
        scope.launch {
            try {
                listenSocket = DatagramSocket(BROADCAST_PORT)
                listenSocket?.broadcast = true
                val buffer = ByteArray(256)
                while (isActive) {
                    val packet = DatagramPacket(buffer, buffer.size)
                    listenSocket?.receive(packet)
                    val message = String(packet.data, 0, packet.length)
                    if (message.startsWith(SERVICE_ID)) {
                        val parts = message.split("|")
                        val name = if (parts.size > 1) parts[1] else "未知"
                        val ip = packet.address.hostAddress ?: continue
                        if (ip == getLocalIpAddress()) continue
                        val device = DeviceInfo(ip, name, ConnectionType.LAN, ip)
                        discoveredMap[ip] = device
                        _discoveredDevices.value = discoveredMap.values.toList()
                    }
                }
            } catch (e: IOException) { }
        }
    }

    override fun startDiscovery() {
        ensureListening()
        isDiscovering = true
        broadcastJob = scope.launch {
            while (isDiscovering) {
                sendBroadcast()
                delay(BROADCAST_INTERVAL)
            }
        }
    }

    private suspend fun sendBroadcast() {
        try {
            val localIp = getLocalIpAddress() ?: return
            val broadcastAddr = getBroadcastAddress() ?: return
            val message = "$SERVICE_ID|${Build.MODEL}|$localIp"
            val data = message.toByteArray()
            val socket = broadcastSocket ?: DatagramSocket().also {
                it.broadcast = true
                broadcastSocket = it
            }
            repeat(3) {
                val packet = DatagramPacket(data, data.size, broadcastAddr, BROADCAST_PORT)
                socket.send(packet)
                delay(100)
            }
        } catch (e: Exception) { }
    }

    override fun stopDiscovery() {
        isDiscovering = false
        broadcastJob?.cancel()
    }

    override fun connect(device: DeviceInfo) {
        ensureListening()
        currentDevice = device
        reconnectAttempts = 0
        totalReconnectCount = 0
        scope.launch {
            try {
                clientSocket = Socket(device.address, PORT)
                clientSocket?.soTimeout = 5000
                manageConnection(clientSocket!!)
            } catch (e: Exception) {
                _connectionState.value = ConnectionState.ERROR
                handleConnectionLost()
            }
        }
    }

    private suspend fun manageConnection(socket: Socket) {
        withContext(Dispatchers.IO) {
            try {
                SecureConnectionHelper.performKeyExchange(socket.getInputStream(), socket.getOutputStream())
                clientSocket = socket
                _connectionState.value = ConnectionState.CONNECTED
                missedHeartbeats = 0
                startDataReceiver()
                startHeartbeat()
            } catch (e: Exception) {
                _connectionState.value = ConnectionState.ERROR
                handleConnectionLost()
            }
        }
    }

    override fun handleConnectionLost() {
        super.handleConnectionLost()
        clientSocket?.close()
        clientSocket = null
        scheduleReconnect {
            attemptReconnect()
        }
    }

    private suspend fun attemptReconnect(): Boolean {
        val device = currentDevice ?: return false
        return try {
            withTimeout(15000L) {
                clientSocket = Socket(device.address, PORT)
                clientSocket?.soTimeout = 5000
                manageConnection(clientSocket!!)
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    override fun disconnect() {
        stopDiscovery()
        super.disconnect()
        clientSocket?.close()
        clientSocket = null
        resetListening()
    }

    override fun close() {
        stopDiscovery()
        super.close()
        clientSocket?.close()
        clientSocket = null
        broadcastSocket?.close()
        broadcastSocket = null
        resetListening()
    }
}