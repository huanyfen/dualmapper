package com.example.dualmapper

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class DualMappingApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}