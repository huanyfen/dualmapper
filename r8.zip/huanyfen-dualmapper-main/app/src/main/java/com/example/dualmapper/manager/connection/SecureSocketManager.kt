package com.example.dualmapper.manager.connection

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

abstract class SecureSocketManager : ConnectionManager {

    protected val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    protected val _connectionState = MutableStateFlow(ConnectionState.IDLE)
    override val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    override val isConnected: Boolean
        get() = _connectionState.value == ConnectionState.CONNECTED

    protected var dataReceivedListener: ((ByteArray) -> Unit)? = null
    private var receiveJob: Job? = null
    private var heartbeatJob: Job? = null
    protected var missedHeartbeats = 0

    protected var currentDevice: DeviceInfo? = null
    protected var reconnectAttempts = 0
    protected open val maxReconnectAttempts: Int = 5
    protected var totalReconnectCount = 0
    protected open val maxTotalReconnect: Int = 10
    private var reconnectJob: Job? = null

    companion object {
        val HEARTBEAT_INTERVAL_MS = 15_000L
        const val MISSED_HEARTBEATS_THRESHOLD = 3
    }

    protected abstract fun getInputStream(): InputStream?
    protected abstract fun getOutputStream(): OutputStream?

    override fun setOnDataReceivedListener(listener: ((ByteArray) -> Unit)?) {
        dataReceivedListener = listener
    }

    protected fun startDataReceiver() {
        receiveJob = scope.launch {
            val input = getInputStream() ?: return@launch
            try {
                while (isActive) {
                    val data = SecureConnectionHelper.receiveDecrypted(input) ?: break
                    // 任何有效数据都代表连接存活，重置心跳计数器
                    missedHeartbeats = 0
                    when {
                        RemoteDataProtocol.isPing(data) -> {
                            sendPong()
                        }
                        RemoteDataProtocol.isPong(data) -> {
                            // 心跳回复已收到
                        }
                        else -> {
                            dataReceivedListener?.invoke(data)
                        }
                    }
                }
            } catch (e: IOException) {
                // 连接断开
            } finally {
                handleConnectionLost()
            }
        }
    }

    protected fun startHeartbeat() {
        heartbeatJob = scope.launch {
            while (isActive && isConnected) {
                delay(HEARTBEAT_INTERVAL_MS)
                try {
                    sendPing()
                    missedHeartbeats++
                    if (missedHeartbeats >= MISSED_HEARTBEATS_THRESHOLD) {
                        handleConnectionLost()
                        break
                    }
                } catch (e: IOException) {
                    handleConnectionLost()
                    break
                }
            }
        }
    }

    override fun send(data: ByteArray) {
        scope.launch {
            try {
                getOutputStream()?.let { SecureConnectionHelper.sendEncrypted(it, data) }
            } catch (e: IOException) {
                // 发送失败
            }
        }
    }

    protected fun sendPing() {
        getOutputStream()?.let { SecureConnectionHelper.sendEncrypted(it, RemoteDataProtocol.createPingPacket()) }
    }

    protected fun sendPong() {
        getOutputStream()?.let { SecureConnectionHelper.sendEncrypted(it, RemoteDataProtocol.createPongPacket()) }
    }

    protected open fun handleConnectionLost() {
        if (_connectionState.value == ConnectionState.DISCONNECTED) return
        _connectionState.value = ConnectionState.DISCONNECTED
        receiveJob?.cancel()
        heartbeatJob?.cancel()
    }

    protected fun scheduleReconnect(connectAction: suspend () -> Boolean) {
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            val device = currentDevice ?: return@launch
            if (reconnectAttempts >= maxReconnectAttempts || totalReconnectCount >= maxTotalReconnect) {
                _connectionState.value = ConnectionState.ERROR
                return@launch
            }
            _connectionState.value = ConnectionState.RECONNECTING
            val delayMs = 3000L * (reconnectAttempts + 1)
            delay(delayMs)
            reconnectAttempts++
            totalReconnectCount++
            val success = try {
                withTimeoutOrNull(15000L) {
                    connectAction()
                } ?: false
            } catch (e: Exception) { false }
            if (success) {
                reconnectAttempts = 0
                totalReconnectCount = 0
            } else {
                scheduleReconnect(connectAction)
            }
        }
    }

    override fun disconnect() {
        reconnectJob?.cancel()
        heartbeatJob?.cancel()
        receiveJob?.cancel()
        _connectionState.value = ConnectionState.IDLE
    }

    override fun close() {
        disconnect()
        scope.cancel()
    }
}