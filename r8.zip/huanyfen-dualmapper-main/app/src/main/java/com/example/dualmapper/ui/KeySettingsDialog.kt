package com.example.dualmapper.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.dualmapper.R

/**
 * 按键设置对话框。
 * 现在不再持有 MappedKeyView，而是通过回调与外界通信，避免内存泄漏。
 *
 * @param currentAlpha 当前透明度 (0f~1f)
 * @param onAlphaChanged 透明度滑块变化时的回调，传入新值
 * @param onDelete 点击删除按钮
 * @param onRemap 点击重新映射按钮
 * @param onChangeIcon 点击更换图标按钮（可选）
 * @param onDismiss 对话框关闭
 */
@Composable
fun KeySettingsDialog(
    currentAlpha: Float,
    onAlphaChanged: (Float) -> Unit,
    onDelete: () -> Unit,
    onRemap: () -> Unit,
    onChangeIcon: (() -> Unit)? = null,
    onDismiss: () -> Unit
) {
    var alpha by remember { mutableStateOf(currentAlpha) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = stringResource(R.string.key_settings),
                color = MaterialTheme.colorScheme.onSurface
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = stringResource(R.string.opacity),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Slider(
                    value = alpha,
                    onValueChange = { newAlpha ->
                        alpha = newAlpha
                        onAlphaChanged(newAlpha) // 通知外界（悬浮窗）
                    },
                    valueRange = 0f..1f,
                    modifier = Modifier.fillMaxWidth()
                )

                if (onChangeIcon != null) {
                    Button(
                        onClick = onChangeIcon,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(stringResource(R.string.change_icon))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onRemap()
                onDismiss()
            }) {
                Text(stringResource(R.string.remap))
            }
        },
        dismissButton = {
            TextButton(onClick = {
                onDelete()
                onDismiss()
            }) {
                Text(
                    stringResource(R.string.delete),
                    color = MaterialTheme.colorScheme.error
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        titleContentColor = MaterialTheme.colorScheme.onSurface,
        textContentColor = MaterialTheme.colorScheme.onSurface
    )
}