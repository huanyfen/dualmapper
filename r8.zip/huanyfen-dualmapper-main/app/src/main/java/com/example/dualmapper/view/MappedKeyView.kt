package com.example.dualmapper.view

import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.dualmapper.R
import java.io.File

open class MappedKeyView(context: Context) : FrameLayout(context) {
    private val iconView: ImageView
    private val labelView: TextView
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = Color.TRANSPARENT
    }

    private var isEditing = false
    private var isSelected = false
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var initialX = 0
    private var initialY = 0
    private val dragThreshold = 10f
    private var isDragging = false
    private var onLongPressListener: (() -> Unit)? = null
    private var onPositionChangedListener: ((x: Int, y: Int) -> Unit)? = null
    private val scaleDetector = ScaleGestureDetector(context, ScaleListener())
    private var isScaling = false
    private var longPressRunnable: Runnable? = null

    var keyId: String = ""
    var actionType: String = "tap"
    var targetX: Float = 0f
    var targetY: Float = 0f
    var endX: Float = 0f
    var endY: Float = 0f
    var duration: Long = 50
    var playerIndex: Int = 1
    var scaleX: Float = 1f
    var scaleY: Float = 1f
    var rotation: Float = 0f
    var iconPath: String? = null

    var label: String
        get() = labelView.text.toString()
        set(value) { labelView.text = value }

    var currentAlpha: Float
        get() = alpha
        set(value) { setOpacity((value * 255).toInt()) }

    var selected: Boolean
        get() = isSelected
        set(value) {
            isSelected = value
            invalidate()
        }

    init {
        val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        inflater.inflate(R.layout.view_mapped_key, this, true)
        iconView = findViewById(R.id.key_icon)
        labelView = findViewById(R.id.key_label)
        setBackgroundColor(Color.TRANSPARENT)
        isClickable = true
        isFocusable = true
        // 默认暗色主题，后续由 FloatingService 更新
        applyTheme(true)
    }

    fun setEditing(editing: Boolean) {
        isEditing = editing
        if (!editing) selected = false
        invalidate()
    }

    fun setOnLongPressListener(listener: () -> Unit) { onLongPressListener = listener }
    fun setOnPositionChangedListener(listener: (x: Int, y: Int) -> Unit) { onPositionChangedListener = listener }

    fun setLabel(text: String) { labelView.text = text }
    fun setLabelTextColor(color: Int) { labelView.setTextColor(color) }

    fun setIcon(drawableRes: Int) { iconView.setImageResource(drawableRes) }

    fun setIconFromFile(file: File) {
        Glide.with(context)
            .load(file)
            .override(128, 128)
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .placeholder(R.drawable.ic_default_floating)
            .error(R.drawable.ic_default_floating)
            .circleCrop()
            .into(iconView)
    }

    fun applyIcon() {
        if (!iconPath.isNullOrEmpty()) {
            val file = File(context.filesDir, iconPath!!)
            if (file.exists()) {
                setIconFromFile(file)
                return
            }
        }
        setIcon(R.drawable.ic_default_floating)
    }

    open fun setOpacity(alpha: Int) {
        this.alpha = alpha / 255f
        iconView.alpha = alpha / 255f
        labelView.alpha = alpha / 255f
    }

    fun applyScale() {
        iconView.scaleX = scaleX
        iconView.scaleY = scaleY
        labelView.scaleX = scaleX
        labelView.scaleY = scaleY
        requestLayout()
    }

    fun setFocused(focused: Boolean) {
        isSelected = focused
        invalidate()
    }

    /**
     * 根据当前主题更新按键图标的背景。
     * @param isDark true 表示暗色主题，false 表示亮色主题。
     */
    fun applyTheme(isDark: Boolean) {
        val bgColor = ContextCompat.getColor(context, if (isDark) R.color.dark_surface else R.color.light_surface)
        val borderColor = ContextCompat.getColor(context, R.color.primary_blue)
        val cornerRadius = 8f.dpToPx(context).toFloat()
        val strokeWidth = 1f.dpToPx(context)

        val drawable = GradientDrawable().apply {
            setColor(bgColor)
            this.cornerRadius = cornerRadius
            setStroke(strokeWidth, borderColor)
        }
        iconView.background = drawable
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (isEditing) {
            borderPaint.color = if (isSelected) {
                ContextCompat.getColor(context, R.color.primary_blue)
            } else {
                ContextCompat.getColor(context, R.color.text_primary)
            }
            borderPaint.strokeWidth = if (isSelected) 8f else 4f
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), borderPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isEditing) return super.onTouchEvent(event)
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                initialTouchX = event.rawX
                initialTouchY = event.rawY
                val params = layoutParams as? FrameLayout.LayoutParams
                initialX = params?.leftMargin ?: 0
                initialY = params?.topMargin ?: 0
                isDragging = false
                isScaling = false
                longPressRunnable?.let { removeCallbacks(it) }
                longPressRunnable = Runnable {
                    if (!isDragging && !isScaling) {
                        selected = !selected
                        onLongPressListener?.invoke()
                    }
                }
                postDelayed(longPressRunnable!!, 500)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (isScaling) return true
                val dx = event.rawX - initialTouchX
                val dy = event.rawY - initialTouchY
                if (Math.hypot(dx.toDouble(), dy.toDouble()) > dragThreshold) {
                    isDragging = true
                    longPressRunnable?.let { removeCallbacks(it) }
                    val parent = parent as? ViewGroup ?: return true
                    val maxLeft = parent.width - width
                    val maxTop = parent.height - height
                    val newLeft = (initialX + dx).toInt().coerceIn(0, maxLeft)
                    val newTop = (initialY + dy).toInt().coerceIn(0, maxTop)
                    val params = layoutParams as FrameLayout.LayoutParams
                    params.leftMargin = newLeft
                    params.topMargin = newTop
                    layoutParams = params
                    onPositionChangedListener?.invoke(newLeft, newTop)
                    initialX = newLeft
                    initialY = newTop
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                longPressRunnable?.let { removeCallbacks(it) }
                isDragging = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                longPressRunnable?.let { removeCallbacks(it) }
                isDragging = false
                return true
            }
            else -> return true
        }
    }

    private inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
            isScaling = true
            longPressRunnable?.let { removeCallbacks(it) }
            return true
        }
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            scaleX = (scaleX * detector.scaleFactor).coerceIn(0.5f, 3.0f)
            scaleY = (scaleY * detector.scaleFactor).coerceIn(0.5f, 3.0f)
            applyScale()
            return true
        }
        override fun onScaleEnd(detector: ScaleGestureDetector) { isScaling = false }
    }
}

/**
 * 将 dp 值转换为 px，避免 Int 截断导致小数值为零。
 */
private fun Number.dpToPx(context: Context): Int {
    return (this.toFloat() * context.resources.displayMetrics.density).toInt()
}