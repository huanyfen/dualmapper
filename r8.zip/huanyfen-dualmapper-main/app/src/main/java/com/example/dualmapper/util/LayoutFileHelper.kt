package com.example.dualmapper.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.dualmapper.data.AppDatabase
import com.example.dualmapper.data.KeyMappingEntity
import com.example.dualmapper.manager.preset.PresetManager
import com.example.dualmapper.service.MappedAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object LayoutFileHelper {
    private const val FILE_PROVIDER_AUTHORITY = "com.example.dualmapper.fileprovider"

    suspend fun exportLayoutToFile(context: Context, database: AppDatabase): Uri? = withContext(Dispatchers.IO) {
        try {
            val keys = database.keyMappingDao().getAll()
            val jsonArray = JSONArray()
            keys.forEach { key ->
                jsonArray.put(JSONObject().apply {
                    put("id", key.id)
                    put("label", key.label)
                    put("layoutX", key.layoutX)
                    put("layoutY", key.layoutY)
                    put("alpha", key.alpha.toDouble())
                    put("actionType", key.actionType)
                    put("targetX", key.targetX.toDouble())
                    put("targetY", key.targetY.toDouble())
                    put("endX", key.endX.toDouble())
                    put("endY", key.endY.toDouble())
                    put("durationMs", key.durationMs)
                    put("keyCode", key.keyCode)
                    put("playerIndex", key.playerIndex)
                    put("scaleX", key.scaleX.toDouble())
                    put("scaleY", key.scaleY.toDouble())
                    put("rotation", key.rotation.toDouble())
                    put("iconPath", key.iconPath ?: "")
                    put("presetId", key.presetId ?: "")
                    put("designWidth", key.designWidth)
                    put("designHeight", key.designHeight)
                })
            }
            val fileName = "dualmapper_layout_${System.currentTimeMillis()}.json"
            val file = File(context.cacheDir, fileName)
            file.writeText(jsonArray.toString())
            FileProvider.getUriForFile(context, FILE_PROVIDER_AUTHORITY, file)
        } catch (e: Exception) {
            null
        }
    }

    suspend fun importLayoutFromUri(context: Context, uri: Uri, database: AppDatabase): Boolean = withContext(Dispatchers.IO) {
        try {
            val jsonString = context.contentResolver.openInputStream(uri)?.use { input ->
                input.bufferedReader().readText()
            } ?: return@withContext false
            if (!isValidLayoutJson(jsonString)) return@withContext false
            val jsonArray = JSONArray(jsonString)
            val presetManager = PresetManager(context, database)
            presetManager.backupCurrent()
            val entities = mutableListOf<KeyMappingEntity>()
            for (i in 0 until jsonArray.length()) {
                KeyMappingEntity.fromJson(jsonArray.getJSONObject(i))?.let { entity ->
                    entities.add(entity)
                }
            }
            database.keyMappingDao().deleteAll()
            database.keyMappingDao().upsertAll(entities)
            MappedAccessibilityService.instance?.refreshMappings()
            context.sendBroadcast(Intent("ACTION_RELOAD_KEYS"))
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * 加强的 JSON 校验，防止导入时因类型不匹配导致崩溃。
     */
    private fun isValidLayoutJson(json: String): Boolean {
        return try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                // 验证字符串字段
                if (obj.optString("id", "").isEmpty() || obj.optString("label", "").isEmpty()) return false
                // 验证整数字段，使用 opt 避免类型错误
                if (obj.optInt("layoutX", -1) < 0) return false
                // actionType 必须存在且为合法值
                val actionType = obj.optString("actionType", "")
                if (actionType !in listOf("tap", "swipe", "longpress")) return false
                // 必要数字字段应存在，不存在时设默认值以保证不抛异常
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}