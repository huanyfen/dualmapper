package com.example.dualmapper.ui.main

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.dualmapper.data.AppDatabase
import com.example.dualmapper.data.PresetLayoutEntity
import com.example.dualmapper.domain.usecase.ApplyPresetUseCase
import com.example.dualmapper.manager.connection.*
import com.example.dualmapper.manager.preset.PresetManager
import com.example.dualmapper.service.FloatingService
import com.example.dualmapper.service.MappedAccessibilityService
import com.example.dualmapper.util.LayoutFileHelper
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class MainUiState(
    val connectionState: ConnectionState = ConnectionState.IDLE,
    val isKeyMappingEnabled: Boolean = true,
    val isRemoteMappingEnabled: Boolean = false,
    val discoveredDevices: List<DeviceInfo> = emptyList(),
    val isLoading: Boolean = false,
    val remoteHostInfo: String? = null
)

sealed class MainEvent {
    data class ApplyPreset(val presetId: String) : MainEvent()
    object RestoreBackup : MainEvent()
    object ToggleKeyMapping : MainEvent()
    object ToggleRemoteMapping : MainEvent()
    object ResetFloatingPosition : MainEvent()
    data class SelectConnectionType(val type: ConnectionType) : MainEvent()
    object StartDiscovery : MainEvent()
    object StartHost : MainEvent()
    data class JoinRemote(val address: String) : MainEvent()
    data class ConnectToDevice(val device: DeviceInfo) : MainEvent()
    object ResetRemoteAuthToken : MainEvent()
}

@HiltViewModel
class MainViewModel @Inject constructor(
    private val application: Application,
    private val applyPresetUseCase: ApplyPresetUseCase,
    private val presetManager: PresetManager,
    private val database: AppDatabase
) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private val _presets = MutableStateFlow<List<PresetLayoutEntity>>(emptyList())
    val presets: StateFlow<List<PresetLayoutEntity>> = _presets.asStateFlow()

    private var currentManager: ConnectionManager? = null
    private var stateCollectJob: Job? = null
    private var discoveryCollectJob: Job? = null

    init {
        viewModelScope.launch {
            presetManager.loadPresets()
            _presets.value = presetManager.getAvailablePresets()

            val prefs = application.getSharedPreferences("settings", 0)
            val keyMappingEnabled = prefs.getBoolean("key_mapping_enabled", true)
            val remoteMappingEnabled = prefs.getBoolean("remote_mapping_enabled", false)
            _uiState.update {
                it.copy(
                    isKeyMappingEnabled = keyMappingEnabled,
                    isRemoteMappingEnabled = remoteMappingEnabled
                )
            }
        }
    }

    fun onEvent(event: MainEvent) {
        when (event) {
            is MainEvent.ApplyPreset -> applyPreset(event.presetId)
            MainEvent.RestoreBackup -> restoreBackup()
            MainEvent.ToggleKeyMapping -> toggleKeyMapping()
            MainEvent.ToggleRemoteMapping -> toggleRemoteMapping()
            MainEvent.ResetFloatingPosition -> resetFloatingPosition()
            is MainEvent.SelectConnectionType -> selectConnectionType(event.type)
            MainEvent.StartDiscovery -> startDiscovery()
            MainEvent.StartHost -> startRemoteHost()
            is MainEvent.JoinRemote -> joinRemote(event.address)
            is MainEvent.ConnectToDevice -> connectToDevice(event.device)
            MainEvent.ResetRemoteAuthToken -> resetRemoteAuthToken()
        }
    }

    private fun applyPreset(presetId: String) {
        viewModelScope.launch { applyPresetUseCase(presetId) }
    }

    private fun restoreBackup() {
        viewModelScope.launch { presetManager.restoreBackup() }
    }

    private fun toggleKeyMapping() {
        val newValue = !_uiState.value.isKeyMappingEnabled
        application.getSharedPreferences("settings", 0)
            .edit().putBoolean("key_mapping_enabled", newValue).apply()
        application.sendBroadcast(
            Intent("ACTION_KEY_MAPPING_TOGGLE").putExtra("enabled", newValue)
        )
        _uiState.update { it.copy(isKeyMappingEnabled = newValue) }
    }

    private fun toggleRemoteMapping() {
        val newValue = !_uiState.value.isRemoteMappingEnabled
        application.getSharedPreferences("settings", 0)
            .edit().putBoolean("remote_mapping_enabled", newValue).apply()
        application.sendBroadcast(
            Intent("ACTION_REMOTE_MAPPING_TOGGLE").putExtra("enabled", newValue)
        )
        _uiState.update { it.copy(isRemoteMappingEnabled = newValue) }
    }

    private fun resetFloatingPosition() {
        application.sendBroadcast(Intent(FloatingService.ACTION_RESET_POSITION))
    }

    private fun selectConnectionType(type: ConnectionType) {
        stateCollectJob?.cancel()
        discoveryCollectJob?.cancel()
        currentManager?.setOnDataReceivedListener(null)
        ConnectionManagerRegistry.cleanup()

        val manager: ConnectionManager = when (type) {
            ConnectionType.WIFI_DIRECT -> WifiDirectManager.getInstance(application).also { it.initialize() }
            ConnectionType.BLUETOOTH -> BluetoothConnectionManager(application)
            ConnectionType.LAN -> LanConnectionManager(application)
            ConnectionType.REMOTE -> RemoteConnectionManager(application)
        }

        manager.setOnDataReceivedListener { data ->
            RemoteDataProtocol.parseExecuteMappingKeyCode(data)?.let { keyCode ->
                MappedAccessibilityService.instance?.onRemoteMappingReceived(keyCode)
            }
        }

        ConnectionManagerRegistry.register(manager)
        currentManager = manager

        stateCollectJob = viewModelScope.launch {
            manager.connectionState.collect { state ->
                _uiState.update { it.copy(connectionState = state) }
            }
        }
        discoveryCollectJob = viewModelScope.launch {
            manager.discoveredDevices.collect { devices ->
                _uiState.update { it.copy(discoveredDevices = devices) }
            }
        }

        if (type != ConnectionType.REMOTE) {
            _uiState.update { it.copy(remoteHostInfo = null) }
        }
    }

    private fun startDiscovery() {
        currentManager?.startDiscovery()
    }

    private fun startRemoteHost() {
        val manager = currentManager
        if (manager !is RemoteConnectionManager) return
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update { it.copy(isLoading = true) }
            try {
                val (success, info) = manager.startHostMode()
                if (success) {
                    _uiState.update { it.copy(remoteHostInfo = info) }
                } else {
                    _uiState.update { it.copy(remoteHostInfo = null) }
                    withContext(Dispatchers.Main) {
                        Toast.makeText(application, info, Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(remoteHostInfo = null) }
                withContext(Dispatchers.Main) {
                    Toast.makeText(application, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            } finally {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    private fun joinRemote(address: String) {
        val manager = currentManager
        if (manager !is RemoteConnectionManager) return
        val device = DeviceInfo(address, address, ConnectionType.REMOTE, address)
        manager.connect(device)
    }

    private fun connectToDevice(device: DeviceInfo) {
        currentManager?.connect(device)
    }

    private fun resetRemoteAuthToken() {
        val manager = currentManager
        if (manager is RemoteConnectionManager) {
            manager.resetAuthToken()
            Toast.makeText(application, "配对码已重置，请重新启动主机", Toast.LENGTH_SHORT).show()
            _uiState.update { it.copy(remoteHostInfo = null) }
        } else {
            Toast.makeText(application, "未处于远程连接模式", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportLayoutToUri(uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                LayoutFileHelper.exportLayoutToFile(application, database)?.let { sourceUri ->
                    application.contentResolver.openInputStream(sourceUri)?.use { input ->
                        application.contentResolver.openOutputStream(uri)?.use { output ->
                            input.copyTo(output)
                        }
                    }
                }
            } finally {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    fun importLayout(uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                val success = LayoutFileHelper.importLayoutFromUri(application, uri, database)
                withContext(Dispatchers.Main) {
                    if (success) {
                        Toast.makeText(application, "导入成功", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(application, "导入失败，请检查文件格式", Toast.LENGTH_SHORT).show()
                    }
                }
            } finally {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        stateCollectJob?.cancel()
        discoveryCollectJob?.cancel()
        ConnectionManagerRegistry.cleanup()
    }
}