package com.example.dualmapper.util

import android.content.Context

object SignatureUtils {
    fun verifySelfSignature(context: Context): Boolean = true
}